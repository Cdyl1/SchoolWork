function setup() {
  createCanvas(600, 500);
  colorMode(RGB);
  frameRate(24);
}
var v = 86;
var w = 86;
var x = 86;
var y = 38;
var z = 40;

function draw() {
  background(250);
  ellipseMode(RADIUS);
  
  noFill();
  stroke(0,0,0);
  strokeWeight(50);
  
  rect(25, 25, 550, 450);
  
  //Color A = 125, 219, 197, 86
  //Color B = 99, 219, 109, 86
  //Color C = 219, 132, 125, 86
  //Color D = 97, 23, 17, 38
  //Color E = 81, 102, 97, 40
  noFill();
  noStroke();
  fill(125, 219, 197, v);
  rect(50, 50, 100, 400);
  
  fill(99, 219, 109, w);
  rect(150, 50, 100, 400);
  
  fill(219, 132, 125, x);
  rect(250, 50, 100, 400);
  
  fill(97, 23, 17, y);
  rect(350, 50, 100, 400);
  
  fill(81, 102, 97, z);
  rect(450, 50, 100, 400);
  
  noFill();
  noStroke();
  
  fill(90, 200, 90);
  ellipse(550, 450, 25, 25);
  
  fill(200, 90, 130);
  rect(25, 425, 50, 50);
  
  if(mouseIsPressed){
     if(mouseX >= 525 && mouseX <= 575 && mouseY >= 425 && mouseY <= 475){
       v = 50;
       w = 100;
       x = 40;
       y = 150;
       z = 60;
     }
    if(mouseX >= 25 && mouseX <= 75 && mouseY >= 425 && mouseY <= 475){
      v = 200;
      w = 220;
      x = 160;
      y = 90;
      z = 180;
    } 
  }
  if(keyIsPressed && mouseX >= 300){
    v = v/2;
    w = w/2;
    x = x/2;
    y = y/2;
    z = z/2;
  }
  if(keyIsPressed && mouseX < 300){
    v = v*2;
    w = w*2;
    x = x*2;
    y = y*2;
    z = z*2;
  }
  
}