function setup() {
  createCanvas(400, 400);
  frameRate(20);
}

var ten = [];
var ooh = [];
var g = 90;
var h = 40;
var k = 200;
var l = 275;
var e = 10;
var v = 65;
var p = 300;
var tr = true;

function draw() {
  background(20);
  fill(70,70,70);
  for(var i = 0; i < 10; i++){
     ten[i]= i*28;
  }
  
  ooh[0] = g;
  ooh[1] = v;
  ooh[2] = l;
  ooh[3] = e;
  ooh[4] = p;
  ooh[5] = h;
  ooh[6] = k;
  ooh[7] = mouseX;
  ooh[8] = mouseY;
  ooh[9] = 0;
  if(tr == true){
    print(ten);
    print(ooh);
    tr = false;
  }
  
  for(var j = 0; j < 10; j++){
    rect(ten[j], ten[j] + ooh[j], 50, 50);
    
    circle(ooh[j], ooh[j] - ten[j], 40);
    
  }
  
}