
function setup() {
  createCanvas(500, 500);
}

var x = 45;


function draw() {
  background(40, 100, 240);
  
  
  translate(0, 450);
  
  push();
  
  fill(20, 200, 50);
  for(var i = 0; i < 10; i++){
    rect(0, 0, 50, 50);
    translate(50, 0);
    
  }
  pop();  
  
  translate(100, -75);
  //fill(33, 33, 33);
  //rect(0,0, 50, 50);
  
  push();
  
  angleMode(DEGREES);
  rotate(x);
  fill(120);
  rect(-50, -50, 100, 100);
  
  pop();
  x++;
  if(x >= 360+45){
    x = 45;
  }
  push();
  translate(162.5, -25);
  fill(225, 20, 20);
  scale(0.5, 2);
  rect(0,0, 50, 50);
  pop();
  
  print("Current Angle:" + x);
  
  
}